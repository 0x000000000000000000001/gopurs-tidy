#!/usr/bin/env python3
"""Remove two measured immutable Tuple round trips in generated insertDefault.

Only generated Go is changed. The existing native values have exactly the
target Tuple field types; no cast, mutation, global memoization or TAST change
is introduced. The Go compiler checks the replacement constructors.
"""
from pathlib import Path
import hashlib
import json
import sys

root = Path(__file__).resolve().parent
output = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / "output"
path = output / "purescript/p_root/0_gopurs_package.go"
source = path.read_text()
before_hash = hashlib.sha256(path.read_bytes()).hexdigest()
tast = {str(p.relative_to(output)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in output.rglob("corefn.json")}

def close_paren(text, start):
    assert text[start] == "("
    depth, quote, escaped = 0, None, False
    for i in range(start, len(text)):
        ch = text[i]
        if quote:
            if escaped:
                escaped = False
            elif ch == "\\" and quote != "`":
                escaped = True
            elif ch == quote:
                quote = None
        elif ch in ('"', "'", "`"):
            quote = ch
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                return i
    raise AssertionError("Unbalanced call")

def native_type(helper):
    start = source.index("func " + helper + "(")
    param_end = close_paren(source, source.index("(", start))
    body = source.index(" {\n\tif in == nil", param_end)
    result = source[param_end + 1:body].strip()
    assert result.startswith("*Constructor_Data_Tuple_Tuple[")
    return result[1:]

token_helper = "Rebox_PureScript_CST_Layout_138441832_1695282224"
state_helper = "Rebox_PureScript_CST_Layout_138441832_623486622"
worker_start = source.index("Call_local_PureScript_CST_Layout___local_var_18_188 = func(")
worker_end = source.index("\n__local_var_18_188 = r_.Func", worker_start)
patches = []
for helper, anchor, fields in [
    (token_helper, "__local_var_22_192 := Call_Data_Array_snoc__2555640181(__local_var_19_189, ",
     "V0: __local_var_21_191, V1: __local_var_22_193"),
    (state_helper, "return ", "V0: __local_var_20_190, V1: __local_var_22_192"),
]:
    prefix = anchor + helper + "("
    start = source.index(prefix, worker_start, worker_end) + len(anchor)
    end = close_paren(source, start + len(helper)) + 1
    original = source[start:end]
    assert "r_.CoerceToStruct[Constructor_Data_Tuple_Tuple[r_.Value, r_.Value]](func() r_.Value {" in original
    assert "&Constructor_Data_Tuple_Tuple[r_.Value, r_.Value]" in original
    replacement = "&" + native_type(helper) + "{" + fields + "}"
    patches.append((start, end, original, replacement))

for start, end, _, replacement in sorted(patches, reverse=True):
    source = source[:start] + replacement + source[end:]
path.write_text(source)
assert tast == {str(p.relative_to(output)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in output.rglob("corefn.json")}
report = {
    "generated_file": str(path.relative_to(output)),
    "before_sha256": before_hash,
    "after_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    "site_count": len(patches),
    "tast_files_unchanged": len(tast),
    "patches": [{"old": old, "new": new} for _, _, old, new in patches],
}
(root / "patch.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "patches"}, indent=2))
