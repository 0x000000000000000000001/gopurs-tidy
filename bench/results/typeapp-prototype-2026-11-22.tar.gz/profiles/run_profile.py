#!/usr/bin/env python3
import json
from pathlib import Path
import subprocess
import sys

profiles = Path(__file__).resolve().parent
label, mode, iterations = sys.argv[1:]
directory = profiles / label
binary = directory / "profile-go"
prefix = directory / "work"
fixture = Path('/Users/0x1/Documents/htdocs/gopurs-tidy/bench/fixture.purs')
process = subprocess.run([str(binary), mode, str(fixture), str(prefix), iterations],
                         capture_output=True, text=True, check=True)
metadata = json.loads(process.stdout)
(directory / (mode + '.json')).write_text(json.dumps(metadata, indent=2) + '\n')
if process.stderr:
    (directory / (mode + '.stderr.log')).write_text(process.stderr)
if mode == 'cpu':
    profile = prefix.with_suffix('.cpu.pprof')
    metrics = [('cpu', [])]
else:
    profile = prefix.with_suffix('.body.alloc.pprof')
    with profile.open('wb') as target:
        subprocess.run(['go', 'tool', 'pprof', '-proto',
                        '-base=' + str(prefix.with_suffix('.base.alloc.pprof')),
                        str(prefix.with_suffix('.alloc.pprof'))],
                       stdout=target, stderr=subprocess.PIPE, check=True)
    metrics = [('alloc_space', ['-sample_index=alloc_space']),
               ('alloc_objects', ['-sample_index=alloc_objects'])]
for metric, options in metrics:
    for sort, extra in [('flat', []), ('cum', ['-cum'])]:
        result = subprocess.run(['go', 'tool', 'pprof', '-top', '-nodecount=40',
                                 '-nodefraction=0', *options, *extra, str(profile)],
                                capture_output=True, text=True, check=True)
        (directory / (metric + '-' + sort + '.txt')).write_text(result.stdout)
print(json.dumps({'label': label, **metadata}, indent=2), flush=True)
