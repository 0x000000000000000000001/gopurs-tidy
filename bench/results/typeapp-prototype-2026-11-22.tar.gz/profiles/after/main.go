package main

import (
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"runtime/pprof"
	"strconv"
	"time"
	p0 "gopurs/output/purescript/p_9d908f11310e0000577fe4656beb887b"
p1 "gopurs/output/purescript/p_root"
_ "gopurs/output/purescript/init_all"
)

func heapProfile(path string) {
	file, err := os.Create(path)
	if err != nil { panic(err) }
	if err := pprof.WriteHeapProfile(file); err != nil { panic(err) }
	if err := file.Close(); err != nil { panic(err) }
}

func main() {
	if len(os.Args) != 5 { panic("expected mode input profile-prefix iterations") }
	mode, input, prefix := os.Args[1], os.Args[2], os.Args[3]
	iterations, err := strconv.Atoi(os.Args[4])
	if err != nil || iterations <= 0 { panic("invalid iterations") }
	if mode != "cpu" && mode != "alloc" { panic("expected cpu or alloc") }
	if mode == "alloc" { runtime.MemProfileRate = 1 }
	data, err := os.ReadFile(input)
	if err != nil { panic(err) }
	source := string(data)
	runtime.GC()
	runtime.GC()
	var cpuFile *os.File
	if mode == "alloc" {
		heapProfile(prefix + ".base.alloc.pprof")
	} else {
		cpuFile, err = os.Create(prefix + ".cpu.pprof")
		if err != nil { panic(err) }
		if err = pprof.StartCPUProfile(cpuFile); err != nil { panic(err) }
	}
	var before, after runtime.MemStats
	runtime.ReadMemStats(&before)
	started := time.Now()
	checksum := 0.0
	for i := 0; i < iterations; i++ {
		checksum += p1.Main_Consume(p0.Call_Main_formatOnce(source))
	}
	elapsed := time.Since(started)
	runtime.ReadMemStats(&after)
	if checksum != float64(iterations) * 3241266008 {
		panic(fmt.Sprintf("checksum mismatch: %v", checksum))
	}
	if mode == "cpu" {
		pprof.StopCPUProfile()
		if err := cpuFile.Close(); err != nil { panic(err) }
	} else {
		// Heap profiles can lag frees by up to two GC cycles.
		runtime.GC()
		runtime.GC()
		heapProfile(prefix + ".alloc.pprof")
	}
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{
		"mode": mode, "iterations": iterations, "checksum": checksum,
		"instrumented": true, "mem_profile_rate": runtime.MemProfileRate,
		"elapsed_seconds": elapsed.Seconds(), "total_alloc_bytes": after.TotalAlloc-before.TotalAlloc,
		"mallocs": after.Mallocs-before.Mallocs, "num_gc": after.NumGC-before.NumGC,
	}); err != nil { panic(err) }
}
