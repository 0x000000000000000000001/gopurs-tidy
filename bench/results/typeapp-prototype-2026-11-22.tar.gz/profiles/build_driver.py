#!/usr/bin/env python3
import json
import os
from pathlib import Path
import re
import subprocess
import sys

output = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
destination.mkdir(parents=True, exist_ok=True)
template = Path(__file__).resolve().with_name("driver.go.in")
module = re.search(r"(?m)^module\s+(\S+)", (output / "go.mod").read_text()).group(1)
symbols = {"Call_Main_formatOnce": [], "Main_Consume": []}
for path in (output / "purescript").rglob("*.go"):
    content = path.read_text()
    for symbol, owners in symbols.items():
        if re.search(r"(?m)^func " + symbol + r"\(", content):
            owners.append(module + "/" + path.parent.relative_to(output).as_posix())
if any(len(owners) != 1 for owners in symbols.values()):
    raise ValueError(symbols)
packages = {path: "p" + str(i) for i, path in enumerate(sorted({v[0] for v in symbols.values()}))}
imports = [f'{alias} "{path}"' for path, alias in packages.items()]
if (output / "purescript/init_all").is_dir():
    imports.append(f'_ "{module}/purescript/init_all"')
source = template.read_text().replace("// GOPURS_IMPORTS", "\n".join(imports))
source = source.replace("FORMAT_CALL", packages[symbols["Call_Main_formatOnce"][0]] + ".Call_Main_formatOnce")
source = source.replace("CONSUME_CALL", packages[symbols["Main_Consume"][0]] + ".Main_Consume")
driver = destination / "main.go"
driver.write_text(source)
binary = destination / "profile-go"
subprocess.run(["go", "build", "-mod=readonly", "-trimpath", "-o", str(binary), str(driver)],
               cwd=output, env={**os.environ, "GOWORK": "off", "GOTOOLCHAIN": "local", "GOPROXY": "off"}, check=True)
print(json.dumps({"binary": str(binary), "symbols": symbols}))
