#!/usr/bin/env python3
"""Measure three prebuilt Go variants against official JavaScript.

This experiment wrapper reuses the repository's measurement protocol. Finish
all builds and profiles before invoking it; it never changes generated sources.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import shutil
import statistics
import sys
import tempfile

sys.dont_write_bytecode = True
LABELS = ("JS", "Go_before", "Go_after", "Go_prototype")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_harness(tidy):
    source = tidy / "bench/measure.py"
    spec = importlib.util.spec_from_file_location("tidy_measure", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tast_check(after, prototype):
    def files(directory):
        return {str(path.relative_to(directory)): path
                for path in directory.rglob("corefn.json")
                if ".gopurs-cache" not in path.parts}
    original, candidate = files(after), files(prototype)
    if not original or original.keys() != candidate.keys():
        raise ValueError("After/prototype TAST module sets differ or are empty")
    hashes = {}
    counts = {"modules": len(original), "data_declarations": 0,
              "class_declarations": 0, "foreign_annotations": 0,
              "type_table_entries": 0, "type_applications": 0,
              "annotations_with_type": 0}
    def walk(value):
        if isinstance(value, dict):
            if value.get("type") == "TypeApp":
                counts["type_applications"] += 1
            annotation = value.get("annotation")
            if isinstance(annotation, dict) and annotation.get("type") is not None:
                counts["annotations_with_type"] += 1
            for child in value.values(): walk(child)
        elif isinstance(value, list):
            for child in value: walk(child)
    for name, path in sorted(original.items()):
        content = path.read_bytes()
        if content != candidate[name].read_bytes():
            raise ValueError("Prototype modified TAST: " + name)
        hashes[name] = hashlib.sha256(content).hexdigest()
        module = json.loads(content)
        for key, count in [("dataDecls", "data_declarations"),
                           ("classDecls", "class_declarations"),
                           ("foreignAnnotations", "foreign_annotations"),
                           ("typeTable", "type_table_entries")]:
            counts[count] += len(module.get(key, []))
        walk(module.get("decls", []))
    return {"after_prototype_byte_identical": True, "counts": counts,
            "corefn_sha256": hashes,
            "scope": "Every generated CoreFn JSON file is byte-identical; "
                     "only generated Go is eligible for the temporary prototype."}


def comparison(candidate, reference, medians, allocated):
    result = {"runtime_ratio": medians[candidate] / medians[reference],
              "runtime_reduction_percent": 100 * (1 - medians[candidate] / medians[reference])}
    for key, name in [("total_alloc_bytes", "allocated_bytes"), ("mallocs", "mallocs")]:
        ratio = allocated[candidate][key] / allocated[reference][key]
        result[name + "_ratio"] = ratio
        result[name + "_reduction_percent"] = 100 * (1 - ratio)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--tidy-root", type=Path, default=Path("/Users/0x1/Documents/htdocs/gopurs-tidy"))
    parser.add_argument("--runs", type=int, default=24,
                        help="Samples per variant, a positive multiple of 24")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.runs < 24 or args.runs % 24:
        parser.error("--runs must be a positive multiple of 24")
    work, tidy = args.workspace.resolve(), args.tidy_root.resolve()
    harness = load_harness(tidy)
    artifacts = {"Go_" + label: (work / label / "output", work / label / "tidy-bench")
                 for label in ("before", "after", "prototype")}
    for output, binary in artifacts.values():
        if not (output / "Main/corefn.json").is_file() or not binary.is_file():
            parser.error("Missing generated Main/corefn.json or binary: " + str(output))
    node = Path(shutil.which("node") or "missing-node").resolve()
    history_path = tidy / "bench/results/typeapp-go-2026-11-22.json"
    history = json.loads(history_path.read_text())
    def fingerprints():
        result = harness.fingerprints(artifacts)
        result["experiment/measure_prototype.py"] = digest(Path(__file__).resolve())
        result["experiment/node_binary"] = digest(node)
        result["experiment/historical_report"] = digest(history_path)
        package = tidy / "bench/output/package.json"
        if package.is_file(): result["bench/output/package.json"] = digest(package)
        return result
    initial = fingerprints()
    tast = tast_check(artifacts["Go_after"][0], artifacts["Go_prototype"][0])
    with tempfile.TemporaryDirectory(prefix="measurement-", dir=work) as temporary:
        directory = Path(temporary)
        drivers = {label: harness.prepare_go_driver(directory / label, output)
                   for label, (output, _) in artifacts.items()}
        checked = harness.verify(drivers, directory)
        if fingerprints() != initial:
            raise RuntimeError("Inputs changed during driver preparation or verification")
        print("35 complete outputs verified; starting balanced runtime campaign", flush=True)
        warmups = [harness.runtime(label, artifacts) for label in LABELS]
        samples = []
        orders = list(itertools.permutations(LABELS))
        for round_index in range(args.runs):
            for position, label in enumerate(orders[round_index % len(orders)]):
                row = harness.runtime(label, artifacts)
                row.update(round=round_index + 1, position=position + 1)
                samples.append(row)
        print("Runtime complete; starting separate allocation measurements", flush=True)
        allocation_runs = []
        for round_index in range(3):
            order = LABELS[round_index:] + LABELS[:round_index]
            for label in order:
                row = harness.allocations(label, drivers.get(label))
                row["round"] = round_index + 1
                allocation_runs.append(row)
        if fingerprints() != initial:
            raise RuntimeError("Inputs changed during runtime/allocation measurements")
        medians = {label: statistics.median(row["seconds"] for row in samples if row["backend"] == label)
                   for label in LABELS}
        runtime_summary = {label: {
            "median_seconds": medians[label], "runs": args.runs,
            "min_seconds": min(row["seconds"] for row in samples if row["backend"] == label),
            "max_seconds": max(row["seconds"] for row in samples if row["backend"] == label)}
            for label in LABELS}
        allocated = {}
        for label in LABELS:
            keys = (["v8_heap_allocation_estimate_bytes", "gc_events", "utf8_buffer_payload_bytes"]
                    if label == "JS" else ["total_alloc_bytes", "mallocs", "num_gc"])
            allocated[label] = {key: statistics.median(row[key] for row in allocation_runs if row["backend"] == label)
                                for key in keys}
        comparisons = {"prototype_vs_after": comparison("Go_prototype", "Go_after", medians, allocated),
                       "prototype_vs_before": comparison("Go_prototype", "Go_before", medians, allocated),
                       "after_vs_before": comparison("Go_after", "Go_before", medians, allocated),
                       "Go_over_JS": {label: medians[label] / medians["JS"] for label in artifacts}}
        frontends = {"JS": (tidy / "bench/output/Main/index.js").read_text().splitlines()[0]}
        frontends.update({label: json.loads((output / "Main/corefn.json").read_text())["builtWith"]
                          for label, (output, _) in artifacts.items()})
        report = {"schema": "tidy-temporary-prototype-v1",
                  "created_at_utc": datetime.now(timezone.utc).isoformat(),
                  "host": {"system": platform.platform(), "machine": platform.machine(),
                           "logical_cpus": os.cpu_count()},
                  "versions": {name: harness.invoke(command).stdout.strip() for name, command in
                               {"node": ["node", "--version"], "go": ["go", "version"]}.items()},
                  "frontends": frontends,
                  "protocol": {"iterations_per_process": harness.ITERATIONS,
                               "runs_per_variant": args.runs, "warmups_per_variant": 1,
                               "timing": "Whole process Main.main including startup, ten complete formatting and UTF-8 consumption iterations",
                               "runtime_order": "All 24 permutations of four variants, repeated in order",
                               "sample_exclusions": "One warmup per variant only; no outlier removal",
                               "allocations": "Three separate runs per variant around formatOnce + consume, excluding input/output I/O",
                               "allocation_order": "Three cyclic rotations of JS, Go_before, Go_after, Go_prototype",
                               "JS_allocation_method": "V8 heap growth between forced GC boundaries; an estimate, not exact Go TotalAlloc equivalence",
                               "profiling_during_timing": False,
                               "gc_environment": {key: os.environ.get(key) for key in
                                                  ["GOGC", "GOMEMLIMIT", "GOMAXPROCS", "GODEBUG", "NODE_OPTIONS"]}},
                  "sources_sha256": initial, "correctness": checked, "tast_preservation": tast,
                  "warmups": warmups, "runtime_runs": samples,
                  "runtime_median_seconds": medians, "runtime_summary": runtime_summary,
                  "allocation_runs": allocation_runs, "allocations_median": allocated,
                  "comparisons": comparisons,
                  "historical_reference": {"source": "altbak.pub application table; bench/results/typeapp-go-2026-11-22.json",
                                           "runtime_median_seconds": history["runtime_median_seconds"],
                                           "allocations_median": history["allocations_median"],
                                           "Go_over_JS": history["Go_over_JS"],
                                           "note": "Historical context; causal comparisons use the current balanced campaign."}}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"runtime_median_seconds": medians, "allocations_median": allocated,
                          "comparisons": comparisons, "verified_cases": len(checked["cases"]),
                          "tast_modules": tast["counts"]["modules"], "output": str(args.output)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
