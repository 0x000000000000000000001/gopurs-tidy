#!/usr/bin/env python3
"""Measure three prebuilt Go variants against official JavaScript.

This experiment wrapper reuses the repository's measurement protocol. Finish
all builds and profiles before invoking it; it never changes generated sources.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import shutil
import statistics
import sys
import tempfile

sys.dont_write_bytecode = True
LABELS = ("JS", "Go_control", "Go_manual", "Go_generic")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_harness(tidy):
    source = tidy / "bench/measure.py"
    spec = importlib.util.spec_from_file_location("tidy_measure", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tast_check(artifacts):
    def files(directory):
        return {str(path.relative_to(directory)): path
                for path in directory.rglob("corefn.json")
                if ".gopurs-cache" not in path.parts}
    modules = {label: files(output) for label, (output, _) in artifacts.items()}
    original = modules["Go_control"]
    if not original or any(original.keys() != value.keys() for value in modules.values()):
        raise ValueError("Go TAST module sets differ or are empty")
    hashes = {}
    counts = {"modules": len(original), "data_declarations": 0,
              "class_declarations": 0, "foreign_annotations": 0,
              "type_table_entries": 0, "type_applications": 0,
              "annotations_with_type": 0}
    def walk(value):
        if isinstance(value, dict):
            if value.get("type") == "TypeApp":
                counts["type_applications"] += 1
            annotation = value.get("annotation")
            if isinstance(annotation, dict) and annotation.get("type") is not None:
                counts["annotations_with_type"] += 1
            for child in value.values(): walk(child)
        elif isinstance(value, list):
            for child in value: walk(child)
    for name, path in sorted(original.items()):
        content = path.read_bytes()
        for label, candidate in modules.items():
            if content != candidate[name].read_bytes():
                raise ValueError(label + " modified TAST: " + name)
        hashes[name] = hashlib.sha256(content).hexdigest()
        module = json.loads(content)
        for key, count in [("dataDecls", "data_declarations"),
                           ("classDecls", "class_declarations"),
                           ("foreignAnnotations", "foreign_annotations"),
                           ("typeTable", "type_table_entries")]:
            counts[count] += len(module.get(key, []))
        walk(module.get("decls", []))
    return {"all_go_tast_byte_identical": True, "variants": list(artifacts),
            "counts": counts, "corefn_sha256": hashes,
            "scope": "Every CoreFn JSON file is byte-identical across the control, "
                     "manual generated-Go patch and generic compiler correction."}


def comparison(candidate, reference, medians, allocated):
    result = {"runtime_ratio": medians[candidate] / medians[reference],
              "runtime_reduction_percent": 100 * (1 - medians[candidate] / medians[reference])}
    for key, name in [("total_alloc_bytes", "allocated_bytes"), ("mallocs", "mallocs")]:
        ratio = allocated[candidate][key] / allocated[reference][key]
        result[name + "_ratio"] = ratio
        result[name + "_reduction_percent"] = 100 * (1 - ratio)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--tidy-root", type=Path, required=True,
                        help="Path to the gopurs-tidy checkout containing the shared measurement harness")
    parser.add_argument("--runs", type=int, default=24,
                        help="Samples per variant, a positive multiple of 24")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.runs < 24 or args.runs % 24:
        parser.error("--runs must be a positive multiple of 24")
    work, tidy = args.workspace.resolve(), args.tidy_root.resolve()
    harness = load_harness(tidy)
    artifacts = {"Go_" + label: (work / label / "output", work / label / "tidy-bench")
                 for label in ("control", "manual", "generic")}
    for output, binary in artifacts.values():
        if not (output / "Main/corefn.json").is_file() or not binary.is_file():
            parser.error("Missing generated Main/corefn.json or binary: " + str(output))
    node_executable = shutil.which("node")
    if not node_executable:
        parser.error("node is not on PATH")
    node = Path(node_executable).resolve()
    history_path = tidy / "bench/results/typeapp-go-2026-11-22.json"
    history = json.loads(history_path.read_text())
    manual_history_path = tidy / "bench/results/typeapp-prototype-2026-11-22.json"
    manual_history = json.loads(manual_history_path.read_text())
    def fingerprints():
        result = harness.fingerprints(artifacts)
        result["experiment/measure_generic.py"] = digest(Path(__file__).resolve())
        result["experiment/node_binary"] = digest(node)
        result["experiment/historical_report"] = digest(history_path)
        result["experiment/manual_historical_report"] = digest(manual_history_path)
        package = tidy / "bench/output/package.json"
        if package.is_file(): result["bench/output/package.json"] = digest(package)
        return result
    initial = fingerprints()
    tast = tast_check(artifacts)
    with tempfile.TemporaryDirectory(prefix="measurement-", dir=work) as temporary:
        directory = Path(temporary)
        drivers = {label: harness.prepare_go_driver(directory / label, output)
                   for label, (output, _) in artifacts.items()}
        checked = harness.verify(drivers, directory)
        if fingerprints() != initial:
            raise RuntimeError("Inputs changed during driver preparation or verification")
        print("35 complete outputs verified; starting balanced runtime campaign", flush=True)
        warmups = [harness.runtime(label, artifacts) for label in LABELS]
        samples = []
        orders = list(itertools.permutations(LABELS))
        for round_index in range(args.runs):
            for position, label in enumerate(orders[round_index % len(orders)]):
                row = harness.runtime(label, artifacts)
                row.update(round=round_index + 1, position=position + 1)
                samples.append(row)
        print("Runtime complete; starting separate allocation measurements", flush=True)
        allocation_runs = []
        for round_index in range(3):
            order = LABELS[round_index:] + LABELS[:round_index]
            for label in order:
                row = harness.allocations(label, drivers.get(label))
                row["round"] = round_index + 1
                allocation_runs.append(row)
        if fingerprints() != initial:
            raise RuntimeError("Inputs changed during runtime/allocation measurements")
        medians = {label: statistics.median(row["seconds"] for row in samples if row["backend"] == label)
                   for label in LABELS}
        runtime_summary = {label: {
            "median_seconds": medians[label], "runs": args.runs,
            "min_seconds": min(row["seconds"] for row in samples if row["backend"] == label),
            "max_seconds": max(row["seconds"] for row in samples if row["backend"] == label)}
            for label in LABELS}
        allocated = {}
        for label in LABELS:
            keys = (["v8_heap_allocation_estimate_bytes", "gc_events", "utf8_buffer_payload_bytes"]
                    if label == "JS" else ["total_alloc_bytes", "mallocs", "num_gc"])
            allocated[label] = {key: statistics.median(row[key] for row in allocation_runs if row["backend"] == label)
                                for key in keys}
        comparisons = {"generic_vs_control": comparison("Go_generic", "Go_control", medians, allocated),
                       "generic_vs_manual": comparison("Go_generic", "Go_manual", medians, allocated),
                       "manual_vs_control": comparison("Go_manual", "Go_control", medians, allocated),
                       "Go_over_JS": {label: medians[label] / medians["JS"] for label in artifacts}}
        frontends = {"JS": (tidy / "bench/output/Main/index.js").read_text().splitlines()[0]}
        frontends.update({label: json.loads((output / "Main/corefn.json").read_text())["builtWith"]
                          for label, (output, _) in artifacts.items()})
        report = {"schema": "tidy-generic-tuple-prototype-v1",
                  "created_at_utc": datetime.now(timezone.utc).isoformat(),
                  "host": {"system": platform.platform(), "machine": platform.machine(),
                           "logical_cpus": os.cpu_count()},
                  "versions": {name: harness.invoke(command).stdout.strip() for name, command in
                               {"node": ["node", "--version"], "go": ["go", "version"]}.items()},
                  "frontends": frontends,
                  "protocol": {"iterations_per_process": harness.ITERATIONS,
                               "runs_per_variant": args.runs, "warmups_per_variant": 1,
                               "timing": "Whole process Main.main including startup, ten complete formatting and UTF-8 consumption iterations",
                               "runtime_order": "All 24 permutations of four variants, repeated in order",
                               "sample_exclusions": "One warmup per variant only; no outlier removal",
                               "allocations": "Three separate runs per variant around formatOnce + consume, excluding input/output I/O",
                               "allocation_order": "Three cyclic rotations of JS, Go_control, Go_manual, Go_generic",
                               "JS_allocation_method": "V8 heap growth between forced GC boundaries; an estimate, not exact Go TotalAlloc equivalence",
                               "profiling_during_timing": False,
                               "gc_environment": {key: os.environ.get(key) for key in
                                                  ["GOGC", "GOMEMLIMIT", "GOMAXPROCS", "GODEBUG", "NODE_OPTIONS"]}},
                  "sources_sha256": initial, "correctness": checked, "tast_preservation": tast,
                  "warmups": warmups, "runtime_runs": samples,
                  "runtime_median_seconds": medians, "runtime_summary": runtime_summary,
                  "allocation_runs": allocation_runs, "allocations_median": allocated,
                  "comparisons": comparisons,
                  "variant_definitions": {
                      "JS": "Official JavaScript frontend, actual Main.main application",
                      "Go_control": "Current compiler sources before generic Tuple correction, JavaScript compiler host",
                      "Go_manual": "Control generated Go with the previous two-site Tuple construction patch",
                      "Go_generic": "Go regenerated by the temporary compiler with generic native Tuple construction"},
                  "historical_reference": {
                      "application_table": {"source": "altbak.pub application table; bench/results/typeapp-go-2026-11-22.json",
                                            "runtime_median_seconds": history["runtime_median_seconds"],
                                            "allocations_median": history["allocations_median"],
                                            "Go_over_JS": history["Go_over_JS"]},
                      "previous_manual_prototype": {"source": "bench/results/typeapp-prototype-2026-11-22.json",
                                                    "runtime_median_seconds": manual_history["runtime_median_seconds"],
                                                    "allocations_median": manual_history["allocations_median"]},
                      "before_typeapp_correction": {
                          "application_campaign_seconds": history["runtime_median_seconds"]["Go_before"],
                          "application_campaign_allocated_bytes": history["allocations_median"]["Go_before"]["total_alloc_bytes"],
                          "manual_prototype_campaign_seconds": manual_history["runtime_median_seconds"]["Go_before"],
                          "manual_prototype_campaign_allocated_bytes": manual_history["allocations_median"]["Go_before"]["total_alloc_bytes"]},
                      "note": "Historical context only; causal comparisons use the current balanced campaign. "
                              "Current control/manual/generic variants all retain the TypeApp-corrected frontend."}}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"runtime_median_seconds": medians, "allocations_median": allocated,
                          "comparisons": comparisons, "verified_cases": len(checked["cases"]),
                          "tast_modules": tast["counts"]["modules"], "output": str(args.output)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
